/**
 * Klasa tworzaca obiekt-fakture skladajaca sie z danych o sprzedajacym, kupujacym i informacji o produkcie
 * <p>
 * Kompilacja: javac InvoiceManagement.java
 * <p>
 * Uruchomienie: java InvoiceManagement
 * <p>
 * @author Krzysztof Witek, KrZZis2015
 * <p>
 * @version 6
 */
public class Invoice {
	
private static int invoiceCounter = 0;
private int invoiceNumber = 1000;
private Contractor seller;
private Contractor buyer;
Product[] products;
	/**
	 * konstruktor wg sprzedawcy, kupujacego i tablicy produktow
	 * @param seller sprzedawca
	 * @param buyer kupujacy
	 * @param products tablica produktow
	 */
	public Invoice(Contractor seller, Contractor buyer, Product[] products) {
		super();
		this.seller = seller;
		this.buyer = buyer;
		this.products = products;
	}

	@Override
	public String toString() {
		invoiceCounter++;
		return String.format("%s", "VAT INVOICE\n\n")
			 + String.format("%-15s%s", "Company:", seller.getName() + ", " + seller.getAddress() + "\n")
			 + String.format("%-15s%s", "TaxNo:", "677-000-21-39\n\n")
			 + String.format("%-15s%s%n%n", "Invoice no:", invoiceNumber+invoiceCounter)
		 	 + String.format("%-15s%s", "Company:", buyer.getName() + ", " + buyer.getAddress() + "\n\n")
		 	 + String.format("%s", " _______________________________________________________________________________\n")
		 	 + String.format("%s", "|No.|Product description                |Quantity|Unit |Total |VAT | VAT |Gross |\n")
		 	 + String.format("%s", "|   |                                   |        |price|      |rate|     |      |\n")
		 	 + String.format("%s", "|---|-----------------------------------|--------|-----|------|----|-----|------|\n");
	}
}